-- Start API keys fresh: removes every existing key and the request log.
-- (Systems that were using old keys stop working immediately - intended.)
DELETE FROM api_request_log;
DELETE FROM api_keys;
