<?php
// ============================================================
//  student/subject_detail.php
//  Student's detailed view of one subject:
//    - Grade breakdown overview
//    - Scores per component (Exam / Written / Performance)
//    - Attendance log
// ============================================================
require_once '../includes/auth.php';
requireRole('student');
require_once '../config/db.php';

$conn->query("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");

$sid        = $_SESSION['student_id'];
$subject_id = (int)($_GET['id'] ?? 0);
$unread_count = getUnreadNotificationCount($conn, $sid);

if (!$subject_id) {
    header("Location: /classroomv2/student/dashboard.php");
    exit;
}

// ── Verify student is enrolled in this subject ───────────────
$chk = $conn->prepare(
    "SELECT e.subject_id FROM subject_enrollments e
     WHERE e.subject_id = ? AND e.student_id = ? LIMIT 1"
);
$chk->bind_param("is", $subject_id, $sid);
$chk->execute();
$chk->store_result();
if ($chk->num_rows === 0) {
    header("Location: /classroomv2/student/dashboard.php");
    exit;
}

// ── Subject info ─────────────────────────────────────────────
// Not filtered to is_active=1 — a subject the teacher has since marked
// inactive (semester ended) must stay viewable here as part of the
// student's subject history (see student/subjects.php).
$subq = $conn->prepare(
    "SELECT sub.*, t.username AS teacher_name
     FROM subjects sub
     LEFT JOIN users t ON t.id = sub.teacher_id
     WHERE sub.id = ?"
);
$subq->bind_param("i", $subject_id);
$subq->execute();
$subject = $subq->get_result()->fetch_assoc();

if (!$subject) {
    header("Location: /classroomv2/student/dashboard.php");
    exit;
}

// ── Grade summary ─────────────────────────────────────────────
$gq = $conn->prepare(
    "SELECT * FROM subject_grades WHERE subject_id = ? AND student_id = ?"
);
$gq->bind_param("is", $subject_id, $sid);
$gq->execute();
$grade = $gq->get_result()->fetch_assoc();

// ── Scores per component ──────────────────────────────────────
$components = ['Major Exam', 'Written Work', 'Performance Task'];
$scores = [];
foreach ($components as $comp) {
    $sq = $conn->prepare(
        "SELECT entry_name, score, total_items, date_given,
                ROUND(score / total_items * 100, 1) AS pct
         FROM score_entries
         WHERE subject_id = ? AND student_id = ? AND component = ?
         ORDER BY date_given ASC, entry_name ASC"
    );
    $sq->bind_param("iss", $subject_id, $sid, $comp);
    $sq->execute();
    $scores[$comp] = $sq->get_result()->fetch_all(MYSQLI_ASSOC);
}

// ── Attendance log ────────────────────────────────────────────
$aq = $conn->prepare(
    "SELECT date, status, time_in
     FROM attendance
     WHERE subject_id = ? AND student_id = ?
     ORDER BY date DESC"
);
$aq->bind_param("is", $subject_id, $sid);
$aq->execute();
$att_rows = $aq->get_result()->fetch_all(MYSQLI_ASSOC);

$att_total   = count($att_rows);
$att_present = 0;
$att_late    = 0;
$att_excused = 0;
$att_absent  = 0;
foreach ($att_rows as $ar) {
    if ($ar['status'] === 'Present')     $att_present++;
    elseif ($ar['status'] === 'Late')    $att_late++;
    elseif ($ar['status'] === 'Excused') $att_excused++;
    else                                  $att_absent++;
}

// ── Active tab ────────────────────────────────────────────────
$active_tab = $_GET['tab'] ?? 'overview';
$valid_tabs = ['overview', 'exam', 'written', 'performance', 'attendance', 'announcements'];
if (!in_array($active_tab, $valid_tabs)) $active_tab = 'overview';

// ── Announcements for this subject ──────────────────────────────
$annq = $conn->prepare(
    "SELECT title, message, created_at FROM announcements
     WHERE subject_id = ? ORDER BY created_at DESC"
);
$annq->bind_param("i", $subject_id);
$annq->execute();
$announcements = $annq->get_result()->fetch_all(MYSQLI_ASSOC);

// ── Type config ───────────────────────────────────────────────
$type_colors = [
    'General Education'      => '#1e5f4e',
    'Professional Education' => '#1e5f4e',
    'Major Subject'          => '#1e5f4e',
];
$subject_color = $type_colors[$subject['subject_type']] ?? '#7aa3ff';

$fg   = (float)($grade['final_grade'] ?? 0);
$pass = $fg >= 75;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title><?php echo htmlspecialchars($subject['subject_code']); ?> — Classroom CMS</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.0.0/dist/tabler-icons.min.css">
    <link rel="stylesheet" href="/classroomv2/assets/style.css">
  <style>body.page-student-subject_detail{--subject-color:<?php echo htmlspecialchars($subject_color, ENT_QUOTES, 'UTF-8'); ?>;}</style>

</head>
<body class="page-student-subject_detail">
<div class="app-shell">


<?php $active_nav = 'subjects'; include __DIR__ . '/_nav.php'; ?>
<main class="main-content">

<div class="page-wrap">

  <a href="/classroomv2/student/dashboard.php" class="back-link">
    <i class="ti ti-arrow-left"></i> Back to Dashboard
  </a>

  <!-- ── SUBJECT HERO ── -->
  <div class="subject-hero">
    <div class="hero-accent"></div>
    <div class="hero-body">
      <div style="flex:1;">
        <div class="hero-code">
          <?php echo htmlspecialchars($subject['subject_code']); ?>
          <?php if (!$subject['is_active']): ?>
          <span style="margin-left:8px;font-size:11px;font-weight:600;padding:3px 10px;border-radius:99px;background:rgba(117,115,115,.15);color:var(--text7);border:1px solid var(--border2);vertical-align:middle;">
            <i class="ti ti-history"></i> Past Semester
          </span>
          <?php endif; ?>
        </div>
        <div class="hero-name"><?php echo htmlspecialchars($subject['subject_name']); ?></div>
        <div class="hero-meta">
          <span class="hero-meta-item"><i class="ti ti-school"></i> <?php echo htmlspecialchars($subject['section']); ?></span>
          <span class="hero-meta-item"><i class="ti ti-calendar"></i> <?php echo htmlspecialchars($subject['semester']); ?> Sem · <?php echo htmlspecialchars($subject['school_year']); ?></span>
          <span class="hero-meta-item"><i class="ti ti-user"></i> <?php echo htmlspecialchars($subject['teacher_name']); ?></span>
          <span style="font-size:11px;padding:2px 9px;border-radius:99px;color:var(--subject-color);background:<?php echo $subject_color; ?>18;border:1px solid <?php echo $subject_color; ?>44;">
            <?php echo htmlspecialchars($subject['subject_type']); ?>
          </span>
        </div>
      </div>
      <div class="hero-grade">
        <?php if ($fg > 0): ?>
        <!-- <div class="grade-big" style="color:<?php echo $pass ? 'var(--green)' : 'var(--red)'; ?>">
          <?php echo number_format($fg, 2); ?>
        </div> -->
        <div class="grade-big" style="color:<?php echo $pass ? 'var(--green)' : 'var(--red)'; ?>">
          <?php echo $grade['letter_grade'] ?? '—'; ?>
          <span style="font-size:11px;color:var(--text7);font-weight:400;"> · <?php echo $pass ? 'PASSED' : 'FAILED'; ?></span>
        </div>
        <div class="grade-label">Final Grade</div>
        <?php else: ?>
        <div class="grade-big text-muted">—</div>
        <div class="grade-label">No grade yet</div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- ── TABS ── -->
  <div class="tabs">
    <?php
    $tabs = [
      'overview'    => [' ',    'Overview'],
      'exam'        => [' ',    'Major Exams'],
      'written'     => [' ',    'Written Works'],
      'performance' => [' ',    'Performance'],
      'attendance'  => [' ',    'Attendance'],
      'announcements' => [' ',  'Announcements'],
    ];
    foreach ($tabs as $key => [$icon, $label]):
    ?>
    <a href="subject_detail.php?id=<?php echo $subject_id; ?>&tab=<?php echo $key; ?>"
       class="tab-link <?php echo $active_tab === $key ? 'active' : ''; ?>">
      <i class="<?php echo $icon; ?>"></i> <?php echo $label; ?>
    </a>
    <?php endforeach; ?>
  </div>

  <!-- ═══════════════════════════════════════════
       TAB: OVERVIEW
  ════════════════════════════════════════════ -->
  <?php if ($active_tab === 'overview'): ?>

  <?php if ($fg === 0.0): ?>
  <div class="notice">
    <i class="ti ti-info-circle" style="color:var(--accent);font-size:15px;"></i>
    No scores have been recorded yet. Your grade will appear here once your teacher enters scores.
  </div>
  <?php endif; ?>

  <!-- Component averages -->
  <div class="stat-grid">
    <div class="stat-box">
      <div class="stat-val">
        <?php echo ($grade && $grade['exam_avg'] > 0) ? number_format($grade['exam_avg'],1).'%' : '—'; ?>
      </div>
      <div class="stat-lbl">Major Exam Avg</div>
    </div>
    <div class="stat-box">
      <div class="stat-val">
        <?php echo ($grade && $grade['written_avg'] > 0) ? number_format($grade['written_avg'],1).'%' : '—'; ?>
      </div>
      <div class="stat-lbl">Written Work Avg</div>
    </div>
    <div class="stat-box">
      <div class="stat-val">
        <?php echo ($grade && $grade['performance_avg'] > 0) ? number_format($grade['performance_avg'],1).'%' : '—'; ?>
      </div>
      <div class="stat-lbl">Performance Avg</div>
    </div>
    <div class="stat-box">
      <div class="stat-val">
        <?php echo ($grade && $grade['attendance_rate'] > 0) ? number_format($grade['attendance_rate'],1).'%' : '—'; ?>
      </div>
      <div class="stat-lbl">Attendance Rate</div>
    </div>
  </div>

  <!-- Grade weights breakdown -->
  <div class="card">
    <p class="card-title"></i> Grade Composition</p>
      <hr class="thin-line">

    <?php
    $breakdown = [
      ['Major Exams',    'var(--bg)', (float)$subject['exam_pct'],        (float)($grade['exam_avg'] ?? 0)],
      ['Written Works',  'var(--bg)', (float)$subject['written_pct'],     (float)($grade['written_avg'] ?? 0)],
      ['Performance',    'var(--bg)', (float)$subject['performance_pct'], (float)($grade['performance_component'] ?? 0)],
    ];
    foreach ($breakdown as [$label, $color, $weight, $avg]):
      $contribution = $avg * $weight / 100;
    ?>
    <div class="gc-row">
      <div class="weight-label">
        <span class="weight-dot" style="background:<?php echo $color; ?>;"></span>
        <?php echo $label; ?>
        <span><?php echo (int)$weight; ?>%</span>
      </div>
      <div class="weight-bar-track">
        <div class="weight-bar-fill" style="width:<?php echo min($avg,100); ?>%;background:<?php echo $color; ?>;opacity:.75;"></div>
      </div>
      <div class="weight-val" style="color:<?php echo $avg>=75?'var(--green)':($avg>0?'var(--red)':'var(--text7)'); ?>;">
        <?php echo $avg > 0 ? number_format($avg,1).'%' : '—'; ?>
      </div>
      <div style="font-family:var(--font-mono);font-size:11px;color:var(--text7);min-width:70px;text-align:right;">
        <?php echo $avg > 0 ? '+'.number_format($contribution,2).' pts' : ''; ?>
      </div>
    </div>
    <?php endforeach; ?>

    <!-- <div style="margin-top:12px;padding-top:12px;border-top:1px solid var(--border);display:flex;align-items:center;justify-content:flex-end;gap:12px;">
      <span>Final Grade</span>
      <span style="font-family:var(--font-head);font-size:20px;font-weight:700;color:<?php echo $pass?'var(--green)':($fg>0?'var(--red)':'var(--text3)'); ?>;">
        <?php echo $fg > 0 ? number_format($fg,2).'%' : '—'; ?>
      </span>
    </div> -->
  </div>

  <!-- Attendance quick stat on overview -->
  <?php if ($att_total > 0): ?>
  <div class="card">
    <p class="card-title"><i class="ti ti-calendar-check" style="color:var(--text7);"></i> Attendance Summary</p>
    <div class="att-summary">
      <div class="att-chip">
        <div class="att-chip-val text-green"><?php echo $att_present; ?></div>
        <div class="att-chip-lbl">Present</div>
      </div>
      <div class="att-chip">
        <div class="att-chip-val" style="color:var(--text6);"><?php echo $att_late; ?></div>
        <div class="att-chip-lbl">Late</div>
      </div>
      <div class="att-chip">
        <div class="att-chip-val" style="color:var(--accent);"><?php echo $att_excused; ?></div>
        <div class="att-chip-lbl">Excused</div>
      </div>
      <div class="att-chip">
        <div class="att-chip-val text-red"><?php echo $att_absent; ?></div>
        <div class="att-chip-lbl">Absent</div>
      </div>
      <div class="att-chip">
        <div class="att-chip-val"><?php echo $att_total; ?></div>
        <div class="att-chip-lbl">Total Days</div>
      </div>
    </div>
    <?php if ($att_total > 0):
      $rate = attendance_rate_pct($att_total, $att_absent, $att_late);
    ?>
    <div style="display:flex;align-items:center;gap:12px;">
      <div style="flex:1;height:8px;background:var(--bg3);border-radius:99px;overflow:hidden;">
        <div style="height:100%;width:<?php echo min($rate,100); ?>%;background:var(--bg);border-radius:99px;"></div>
      </div>
      <span style="font-family:var(--font-mono);font-size:13px;color:var(--text6);"><?php echo number_format($rate,1); ?>%</span>
    </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <!-- ═══════════════════════════════════════════
       TAB: SCORES (Exam / Written / Performance)
  ════════════════════════════════════════════ -->
  <?php else:
    $comp_map = [
      'exam'        => ['Major Exam',       '#7aa3ff', ' '],
      'written'     => ['Written Work',     '#34d399', ' '],
      'performance' => ['Performance Task', '#fbbf24', ' '],
    ];

    if (isset($comp_map[$active_tab])):
      [$comp_name, $comp_color, $comp_icon] = $comp_map[$active_tab];
      $comp_scores = $scores[$comp_name];
      $avg = count($comp_scores) > 0
        ? array_sum(array_column($comp_scores, 'pct')) / count($comp_scores)
        : 0;
  ?>

  <style>
    .xl-table-wrap{overflow-x:auto;border:1px solid var(--border2);border-radius:6px;}
    table.xl-table{width:100%;border-collapse:collapse;font-size:12.5px;}
    table.xl-table th,table.xl-table td{border:1px solid var(--border2);padding:4px 8px;text-align:left;white-space:nowrap;}
    table.xl-table thead th{background:var(--bg5);font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.03em;color:var(--text7);position:sticky;top:0;}
    table.xl-table td.xl-num{font-family:var(--font-mono);text-align:right;}
    table.xl-table tbody tr:nth-child(even){background:var(--bg6);}
    table.xl-table tfoot td{background:var(--bg5);font-weight:600;border-top:2px solid var(--border2);}
  </style>

  <div class="card">
    <p class="card-title">
      <i class="ti <?php echo $comp_icon; ?>" style="color:<?php echo $comp_color; ?>;"></i>
      <?php echo $comp_name; ?> Scores
      <?php if ($avg > 0): ?>
      <span style="margin-left:auto;font-size:13px;font-weight:600;font-family:var(--font-head);color:<?php echo $avg>=75?'var(--green)':'var(--red)'; ?>;">
        Avg: <?php echo number_format($avg,1); ?>%
      </span>
      <?php endif; ?>
    </p>

  <hr class="thin-line">

    <?php if (empty($comp_scores)): ?>
    <div class="empty-state">
      <i class="ti <?php echo $comp_icon; ?> text-muted"></i>
      <p  class="text-muted">No <?php echo strtolower($comp_name); ?> scores recorded yet.</p>
    </div>
    <?php else: ?>
    <div class="xl-table-wrap">
      <table class="xl-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Date</th>
            <th>Score</th>
            <th>Total</th>
            <th>%</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($comp_scores as $i => $sc):
            $pct  = (float)$sc['pct'];
            $pass = $pct >= 75;
          ?>
          <tr>
            <td class="xl-num"><?php echo $i + 1; ?></td>
            <td><?php echo htmlspecialchars($sc['entry_name']); ?></td>
            <td><?php echo $sc['date_given'] ? date('M d, Y', strtotime($sc['date_given'])) : '—'; ?></td>
            <td class="xl-num"><?php echo number_format((float)$sc['score'], 1); ?></td>
            <td class="xl-num"><?php echo (int)$sc['total_items']; ?></td>
            <td class="xl-num" style="color:<?php echo $pass?'var(--green)':'var(--red)'; ?>;"><?php echo number_format($pct,1); ?>%</td>
          </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr>
            <td colspan="5"><?php echo count($comp_scores); ?> entr<?php echo count($comp_scores)===1?'y':'ies'; ?> — Average</td>
            <td class="xl-num" style="color:<?php echo $avg>=75?'var(--green)':($avg>0?'var(--red)':'var(--text7)'); ?>;">
              <?php echo $avg > 0 ? number_format($avg,1).'%' : '—'; ?>
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
    <?php endif; ?>
  </div>

  <!-- ═══════════════════════════════════════════
       TAB: ATTENDANCE
  ════════════════════════════════════════════ -->
  <?php elseif ($active_tab === 'attendance'): ?>

  <div class="card">
    <p class="card-title"></i> Attendance Log</p>

    <?php if ($att_total === 0): ?>
    <div class="empty-state">
      <i class="ti ti-calendar-off text-muted"></i>
      <p  class="text-muted">No attendance records yet.</p>
    </div>
    <?php else: ?>

    <!-- Summary chips -->
    <div class="att-summary">
      <div class="att-chip">
        <div class="att-chip-val text-green"><?php echo $att_present; ?></div>
        <div class="att-chip-lbl">Present</div>
      </div>
      <div class="att-chip">
        <div class="att-chip-val" style="color:var(--text6);"><?php echo $att_late; ?></div>
        <div class="att-chip-lbl">Late</div>
      </div>
      <div class="att-chip">
        <div class="att-chip-val" style="color:var(--accent);"><?php echo $att_excused; ?></div>
        <div class="att-chip-lbl">Excused</div>
      </div>
      <div class="att-chip">
        <div class="att-chip-val text-red"><?php echo $att_absent; ?></div>
        <div class="att-chip-lbl">Absent</div>
      </div>
      <div class="att-chip">
        <div class="att-chip-val"><?php echo $att_total; ?></div>
        <div class="att-chip-lbl">Total Days</div>
      </div>
    </div>

    <!-- Rate bar -->
    <?php
      $rate = attendance_rate_pct($att_total, $att_absent, $att_late);
    ?>
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;">
      <span>Attendance Rate</span>
      <div style="flex:1;height:8px;background:var(--bg3);border-radius:99px;overflow:hidden;">
        <div style="height:100%;width:<?php echo min($rate,100); ?>%;background:var(--bg);border-radius:99px;"></div>
      </div>
      <span style="font-family:var(--font-mono);font-size:13px;color:var(--text6);white-space:nowrap;">
        <?php echo number_format($rate, 1); ?>%
      </span>
    </div>

    <!-- Per-day log -->
    <div class="att-list">
      <?php foreach ($att_rows as $ar):
        $status_class = match($ar['status']) {
          'Present' => 'status-present',
          'Late'    => 'status-late',
          'Excused' => 'status-excused',
          default   => 'status-absent',
        };
      ?>
      <div class="att-row">
        <span class="att-date"><?php echo date('D, M d Y', strtotime($ar['date'])); ?></span>
        <span class="att-time">
          <!-- <?php echo $ar['time_in'] ? 'Time in: '.date('g:i A', strtotime($ar['time_in'])) : ''; ?> -->
        </span>
        <span class="status-badge <?php echo $status_class; ?>"><?php echo $ar['status']; ?></span>
      </div>
      <?php endforeach; ?>
    </div>

    <?php endif; ?>
  </div>

  <!-- ═══════════════════════════════════════════
       TAB: ANNOUNCEMENTS
  ════════════════════════════════════════════ -->
  <?php elseif ($active_tab === 'announcements'): ?>

  <div class="card">
    <p class="card-title"></i> Announcements</p>

    <?php if (empty($announcements)): ?>
    <div class="empty-state">
      <i class="ti ti-speakerphone-off text-muted"></i>
      <p class="text-muted">No announcements posted for this subject yet.</p>
    </div>
    <?php else: foreach ($announcements as $ann): ?>
    <div style="padding:14px 0;border-top:1px solid var(--border);">
      <div style="font-weight:600;font-size:14px;"><?php echo htmlspecialchars($ann['title']); ?></div>
      <div style="font-size:12px;color:var(--text7);margin-top:2px;"><?php echo date('M d, Y g:i A', strtotime($ann['created_at'])); ?></div>
      <p style="font-size:13.5px;margin-top:8px;white-space:pre-wrap;"><?php echo htmlspecialchars($ann['message']); ?></p>
    </div>
    <?php endforeach; endif; ?>
  </div>

  <?php endif; /* comp_map / attendance / announcements */ ?>
  <?php endif; /* overview vs other tabs */ ?>

</div><!-- end page-wrap -->
</main>
</div>
<script src="/classroomv2/assets/ui.js" defer></script>
<script src="/classroomv2/assets/pwa.js" defer></script>
</body>
</html>