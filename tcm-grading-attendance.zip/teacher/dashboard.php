<!------cat > /mnt/user-data/outputs/classroom_v2/teacher/dashboard.php << 'PHPEOF'--->
<?php
// ============================================================
//  teacher/dashboard.php  —  v2 redesign
//  Self-contained page (no header.php include).
//  Shows subject cards, quick stats, at-risk alerts.
// ============================================================
require_once '../includes/auth.php';
requireRole('teacher');
require_once '../config/db.php';

$teacher_id = $_SESSION['user_id'];

// ── Onboarding check: has this teacher set anything up yet? ──
// Drives the getting-started card below — only shown for a brand
// new / empty account, and tells them exactly which step they're on.
$onboard_stmt = $conn->prepare(
    "SELECT
        (SELECT COUNT(*) FROM sections WHERE teacher_id = ?)       AS section_count,
        (SELECT COUNT(*) FROM subjects WHERE teacher_id = ?)       AS subject_count_any"
);
$onboard_stmt->bind_param("ii", $teacher_id, $teacher_id);
$onboard_stmt->execute();
$onboard = $onboard_stmt->get_result()->fetch_assoc();

// ── Subjects with per-subject stats ─────────────────────────
$subjects_stmt = $conn->prepare(
    "SELECT s.*,
        (SELECT COUNT(*)
         FROM subject_enrollments
         WHERE subject_id = s.id)                                          AS enrollee_count,
        (SELECT ROUND(AVG(final_grade),1)
         FROM subject_grades
         WHERE subject_id = s.id AND final_grade > 0)                     AS class_avg,
        (SELECT COUNT(*)
         FROM subject_grades
         WHERE subject_id = s.id AND final_grade >= " . PASSING_GRADE . ")                   AS passing,
        (SELECT COUNT(*)
         FROM subject_grades
         WHERE subject_id = s.id AND final_grade > 0 AND final_grade < " . PASSING_GRADE . ") AS failing,
        (SELECT COUNT(DISTINCT date)
         FROM attendance
         WHERE subject_id = s.id)                                         AS class_days
     FROM subjects s
     WHERE s.teacher_id = ? AND s.is_active = 1
     ORDER BY s.semester DESC, s.subject_name ASC"
);
$subjects_stmt->bind_param("i", $teacher_id);
$subjects_stmt->execute();
$all_subs = $subjects_stmt->get_result();

// ── Summary numbers ──────────────────────────────────────────
$totals_stmt = $conn->prepare(
    "SELECT
        COUNT(DISTINCT s.id)            AS total_subjects,
        COUNT(DISTINCT e.student_id)    AS total_students,
        ROUND(AVG(g.final_grade),1)     AS overall_avg,
        SUM(g.final_grade >= " . PASSING_GRADE . ")        AS total_passing,
        SUM(g.final_grade > 0 AND g.final_grade < " . PASSING_GRADE . ") AS total_failing
     FROM subjects s
     LEFT JOIN subject_enrollments e ON e.subject_id = s.id
     LEFT JOIN subject_grades g      ON g.subject_id = s.id
     WHERE s.teacher_id = ? AND s.is_active = 1"
);
$totals_stmt->bind_param("i", $teacher_id);
$totals_stmt->execute();
$t = $totals_stmt->get_result()->fetch_assoc();

// ── At-risk students (failing in any subject) ────────────────
$at_risk = $conn->prepare(
    "SELECT st.student_id, st.last_name, st.first_name,
            sub.subject_code, sub.subject_name, sub.section,
            g.final_grade, g.letter_grade
     FROM subject_grades g
     JOIN students st   ON st.student_id  = g.student_id
     JOIN subjects sub  ON sub.id         = g.subject_id
     WHERE sub.teacher_id = ? AND g.final_grade > 0 AND g.final_grade < " . PASSING_GRADE . "
     ORDER BY g.final_grade ASC
     LIMIT 8"
);
$at_risk->bind_param("i", $teacher_id);
$at_risk->execute();
$risk_result = $at_risk->get_result();

// ── Recent score entries ─────────────────────────────────────
$recent_stmt = $conn->prepare(
    "SELECT se.entry_name, se.component, se.score, se.total_items,
            se.date_given, st.last_name, st.first_name,
            sub.subject_code
     FROM score_entries se
     JOIN students st  ON st.student_id = se.student_id
     JOIN subjects sub ON sub.id        = se.subject_id
     WHERE sub.teacher_id = ?
     ORDER BY se.created_at DESC
     LIMIT 6"
);
$recent_stmt->bind_param("i", $teacher_id);
$recent_stmt->execute();
$recent = $recent_stmt->get_result();

// ── Top & Lowest performers, scoped per subject ───────────────
// Step 1: for each subject, find every activity (exam / written work /
// performance task) and when it was last entered.
$la_all_stmt = $conn->prepare(
    "SELECT se.subject_id, se.component, se.entry_name, se.total_items,
            se.date_given, sub.subject_code, sub.subject_name, sub.section,
            MAX(se.created_at) AS latest_created
     FROM score_entries se
     JOIN subjects sub ON sub.id = se.subject_id
     WHERE sub.teacher_id = ? AND sub.is_active = 1
     GROUP BY se.subject_id, se.component, se.entry_name, se.total_items,
              se.date_given, sub.subject_code, sub.subject_name, sub.section
     ORDER BY latest_created DESC"
);
$la_all_stmt->bind_param("i", $teacher_id);
$la_all_stmt->execute();
$la_rows = $la_all_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Keep only each subject's single most-recent activity. Rows are already
// ordered newest-first, so the first time a subject_id is seen is its latest.
$latest_by_subject = [];
foreach ($la_rows as $row) {
    if (!isset($latest_by_subject[$row['subject_id']])) {
        $latest_by_subject[$row['subject_id']] = $row;
    }
}

// Only show the 5 subjects with the most recent activity (array is already
// newest-first, and array_slice with preserve_keys keeps the subject ids).
$perf_total_subjects = count($latest_by_subject);
$latest_by_subject   = array_slice($latest_by_subject, 0, 5, true);

// Step 2: for each subject's latest activity, rank every student's score
// and split into up to 3 top performers and up to 3 lowest performers
// (never overlapping, even when the class only has a few scores).
$subject_perf = []; // subject_id => ['activity'=>row, 'top'=>[...], 'bottom'=>[...]]
foreach ($latest_by_subject as $sid => $act) {
    $pf_stmt = $conn->prepare(
        "SELECT st.student_id, st.last_name, st.first_name, se.score, se.total_items
         FROM score_entries se
         JOIN students st ON st.student_id = se.student_id
         WHERE se.subject_id = ? AND se.component = ? AND se.entry_name = ?
         ORDER BY se.score DESC, st.last_name ASC"
    );
    $pf_stmt->bind_param("iss", $sid, $act['component'], $act['entry_name']);
    $pf_stmt->execute();
    $pf_rows  = $pf_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $pf_count = count($pf_rows);

    $top_n    = min(3, $pf_count);
    $bottom_n = min(3, max(0, $pf_count - $top_n));

    $subject_perf[$sid] = [
        'activity' => $act,
        'top'      => array_slice($pf_rows, 0, $top_n),
        'bottom'   => $bottom_n > 0
            ? array_reverse(array_slice($pf_rows, $pf_count - $bottom_n, $bottom_n))
            : [],
    ];
}


$type_cfg = [
    'General Education'      => ['color'=>'#1e5f4e','bg'=>'rgba(91,141,238,.1)', 'label'=>'GE'],
    'Professional Education' => ['color'=>'#1e5f4e','bg'=>'rgba(52,211,153,.1)', 'label'=>'PE'],
    'Major Subject'          => ['color'=>'#1e5f4e','bg'=>'rgba(251,191,36,.1)', 'label'=>'MAJ'],
];

$comp_colors = [
    'Major Exam'       => ['color'=>'#7aa3ff','icon'=>'ti-file-certificate'],
    'Written Work'     => ['color'=>'#34d399','icon'=>'ti-pencil'],
    'Performance Task' => ['color'=>'#fbbf24','icon'=>'ti-star'],
];

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Dashboard — Classroom CMS</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.0.0/dist/tabler-icons.min.css">
    <link rel="stylesheet" href="/classroomv2/assets/style.css">
    <style>
      /* Collapsed-by-default "Getting Started" reminder card (see teacher/dashboard.php) */
      .getting-started-mini > summary { outline: none; }
      .getting-started-mini > summary::-webkit-details-marker { display: none; }
      .getting-started-mini > summary::marker { content: ""; }
    </style>

</head>
<body class="page-teacher-dashboard">
<div class="app-shell">


<!-- ── NAVBAR ── -->
<?php $active_nav = 'dashboard'; include __DIR__ . '/_nav.php'; ?>
<main class="main-content">

<div class="page-wrap">

  <!-- ── WELCOME BANNER ── -->
  <?php
    $dn_q = $conn->prepare("SELECT display_name FROM users WHERE id = ? LIMIT 1");
    $dn_q->bind_param("i", $teacher_id);
    $dn_q->execute();
    $dn_row = $dn_q->get_result()->fetch_assoc();
    $teacher_name = trim($dn_row['display_name'] ?? '') !== '' ? $dn_row['display_name'] : $_SESSION['username'];
  ?>
  <div class="welcome-banner">
    <div class="welcome-text">
      <h1><?php echo htmlspecialchars($teacher_name); ?></h1>
      <p><?php echo date('l, F d Y'); ?> &nbsp;·&nbsp; <?php echo (int)($t['total_subjects']??0); ?> active subject<?php echo ($t['total_subjects']??0)!=1?'s':''; ?> this semester</p>
    </div>
  </div>
  <hr class="thin-line">



  <!-- ── GETTING STARTED ── -->
  <!-- Brand-new account (no section AND no subject yet): full, can't-miss card. -->
  <?php if ((int)$onboard['section_count'] === 0 && (int)$onboard['subject_count_any'] === 0): ?>
  <div class="card" style="margin-bottom:20px;border-left:3px solid var(--bg);">
    <p class="card-title"><i class="ti ti-rocket"></i> Getting Started</p>
    <p style="font-size:13px;color:var(--text7);margin-bottom:18px;">
      Your account is empty — here's the order that works, and why. Each step unlocks the next one.
    </p>

    <div style="display:flex;flex-direction:column;gap:14px;">
      <div style="display:flex;gap:12px;">
        <div style="flex-shrink:0;width:26px;height:26px;border-radius:50%;background:var(--bg);color:#fff;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;">1</div>
        <div>
          <div style="font-weight:600;font-size:13.5px;color:var(--text6);">Create a Section first</div>
          <div style="font-size:12.5px;color:var(--text7);margin-top:2px;">
            A section is the home for a group of students (e.g. "BSIT 2-A") — their masterlist.
            Go to <strong>Sections</strong> → <em>New Section</em>. You need this before you can add
            students, because adding a student asks which section they belong to.
          </div>
        </div>
      </div>
      <div style="display:flex;gap:12px;">
        <div style="flex-shrink:0;width:26px;height:26px;border-radius:50%;background:var(--bg);color:#fff;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;">2</div>
        <div>
          <div style="font-weight:600;font-size:13.5px;color:var(--text6);">Add students to that section</div>
          <div style="font-size:12.5px;color:var(--text7);margin-top:2px;">
            Go to <strong>Students</strong> → add them one at a time, or use
            <em>Import from CSV/Excel</em> to bring in a whole class list at once. It is advisable to download the CSV template to avoid errors.
          </div>
        </div>
      </div>
      <div style="display:flex;gap:12px;">
        <div style="flex-shrink:0;width:26px;height:26px;border-radius:50%;background:var(--bg);color:#fff;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;">3</div>
        <div>
          <div style="font-weight:600;font-size:13.5px;color:var(--text6);">Create a Subject</div>
          <div style="font-size:12.5px;color:var(--text7);margin-top:2px;">
            A subject is the actual class you teach (e.g. "CS101 — Intro to Programming") with its
            own grade weights and schedule. This is separate from the section on purpose — the same
            section of students can take several of your subjects.
          </div>
        </div>
      </div>
      <div style="display:flex;gap:12px;">
        <div style="flex-shrink:0;width:26px;height:26px;border-radius:50%;background:var(--bg);color:#fff;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;">4</div>
        <div>
          <div style="font-weight:600;font-size:13.5px;color:var(--text6);">Enroll the section into the subject</div>
          <div style="font-size:12.5px;color:var(--text7);margin-top:2px;">
            Open the subject → <strong>Settings</strong> tab → <em>Enroll Entire Section</em> to add
            everyone at once (or enroll individual students). Now you can record scores and attendance.
          </div>
        </div>
      </div>
    </div>

    <div style="margin-top:20px;padding-top:16px;border-top:1px solid var(--border2);display:flex;gap:10px;flex-wrap:wrap;">
      <a href="/classroomv2/teacher/manage_sections.php" class="btn btn-primary" style="display:inline-flex;">
        <i class="ti ti-building-community"></i> Start: Create a Section
      </a>
    </div>

    <p style="font-size:11.5px;color:var(--text7);margin-top:14px;margin-bottom:0;">
      <i class="ti ti-info-circle"></i> When a semester ends, you don't have to delete anything —
      mark the subject inactive from its Settings tab and its roster stays ready for next time.
    </p>
  </div>
  <?php else: ?>
  <!-- Already has at least a section or a subject: never fully remove the guide —
       just tuck it out of the way as a small, collapsed-by-default card so it
       doesn't compete with real data, but is one click away if they forget a step. -->
  <details class="card getting-started-mini" style="margin-bottom:20px;border-left:3px solid var(--bg);margin-top:25px;">
    <summary style="cursor:pointer;list-style:none;display:flex;align-items:center;gap:8px;">
      <i class="ti ti-rocket"></i>
      <span class="card-title" style="margin:0;">Getting Started Guide</span>
      <span style="font-size:11.5px;font-weight:400;color:var(--text7);">— click to review the setup steps again</span>
      <i class="ti ti-chevron-down" style="margin-left:auto;"></i>
    </summary>

    <div style="margin-top:16px;display:flex;flex-direction:column;gap:12px;">
      <div style="display:flex;gap:10px;">
        <div style="flex-shrink:0;width:22px;height:22px;border-radius:50%;background:var(--bg);color:#fff;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;">1</div>
        <div style="font-size:12.5px;color:var(--text7);"><strong style="color:var(--text6);">Create a Section</strong> — the home for a group of students (<strong>Sections</strong> → <em>New Section</em>).</div>
      </div>
      <div style="display:flex;gap:10px;">
        <div style="flex-shrink:0;width:22px;height:22px;border-radius:50%;background:var(--bg);color:#fff;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;">2</div>
        <div style="font-size:12.5px;color:var(--text7);"><strong style="color:var(--text6);">Add students</strong> to that section, one at a time or via <em>Import from CSV/Excel</em>. It is advisable to download the CSV template to avoid errors.</div>
      </div>
      <div style="display:flex;gap:10px;">
        <div style="flex-shrink:0;width:22px;height:22px;border-radius:50%;background:var(--bg);color:#fff;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;">3</div>
        <div style="font-size:12.5px;color:var(--text7);"><strong style="color:var(--text6);">Create a Subject</strong> — the actual class you teach, with its own grade weights and schedule.</div>
      </div>
      <div style="display:flex;gap:10px;">
        <div style="flex-shrink:0;width:22px;height:22px;border-radius:50%;background:var(--bg);color:#fff;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;">4</div>
        <div style="font-size:12.5px;color:var(--text7);"><strong style="color:var(--text6);">Enroll the section into the subject</strong> — subject → <strong>Settings</strong> → <em>Enroll Entire Section</em> — then you can record scores and attendance.</div>
      </div>
    </div>

    <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--border2);display:flex;gap:10px;flex-wrap:wrap;">
      <a href="/classroomv2/teacher/manage_sections.php" class="btn btn-outline" style="display:inline-flex;">
        <i class="ti ti-building-community"></i> Sections
      </a>
      <a href="/classroomv2/teacher/add_subject.php" class="btn btn-outline" style="display:inline-flex;">
        <i class="ti ti-book-plus"></i> Subjects
      </a>
    </div>
  </details>
  <?php endif; ?>

  <!-- ── SUBJECT CARDS ── -->
  <?php if ($all_subs->num_rows === 0): ?>
    <?php if ((int)$onboard['section_count'] > 0 || (int)$onboard['subject_count_any'] > 0): ?>
    <div class="card" style="text-align:center;padding:64px 24px;">
      <i class="ti ti-books" style="font-size:44px;color:var(--text7);display:block;margin-bottom:16px;"></i>
      <p style="font-family:var(--font-head);font-size:18px;font-weight:700;color:var(--text7);margin-bottom:8px;">No active subjects</p>
      <p style="font-size:13px;color:var(--text7);margin-bottom:24px;">
        <?php echo (int)$onboard['subject_count_any'] === 0 ? 'Create a subject to get started.' : 'Create a new subject, or reactivate one from All Subjects.'; ?>
      </p>
      <a href="/classroomv2/teacher/add_subject.php" class="btn btn-primary" style="display:inline-flex;">
        <i class="ti ti-book-plus"></i> Add a Subject
      </a>
    </div>
    <?php endif; ?>
  <?php else:
    $all_subs->data_seek(0);
  ?>
  <?php endif; ?>


  <!-- ── BOTTOM: At-risk + Recent activity ── -->
  <?php if (($t['total_subjects']??0) > 0): ?>
  <div class="bottom-grid" style="margin-top:28px;">

    <!-- Passing rate per subject-section -->
    <div class="card">
      <p class="card-title">Passing Rate by Subject-Section</p>
      <?php
      $all_subs->data_seek(0);
      $has_any_graded = false;
      ?>
      <?php while ($ps = $all_subs->fetch_assoc()):
        $graded = (int)$ps['passing'] + (int)$ps['failing'];
        $rate   = $graded > 0 ? round($ps['passing'] / $graded * 100) : null;
        if ($rate !== null) $has_any_graded = true;
        $bar_color = $rate === null ? 'var(--text7)' : ($rate >= 75 ? 'var(--green)' : ($rate >= 50 ? '#fbbf24' : 'var(--red)'));
      ?>
      <div style="margin-bottom:14px;">
        <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:5px;">
          <span style="font-size:12.5px;font-weight:600;color:var(--text6);">
            <?php echo htmlspecialchars($ps['subject_code']); ?> &middot; <?php echo htmlspecialchars($ps['section']); ?>
          </span>
          <span style="font-size:12px;color:<?php echo $bar_color; ?>;font-weight:600;">
            <?php echo $rate === null ? 'No grades yet' : $rate . '%'; ?>
          </span>
        </div>
        <div style="height:7px;border-radius:99px;background:var(--bg6);overflow:hidden;">
          <div style="height:100%;width:<?php echo $rate ?? 0; ?>%;background:<?php echo $bar_color; ?>;border-radius:99px;"></div>
        </div>
        <div style="font-size:10.5px;color:var(--text7);margin-top:3px;">
          <?php echo $graded > 0 ? "{$ps['passing']} of {$graded} graded students passing" : "{$ps['enrollee_count']} enrolled, none graded yet"; ?>
        </div>
      </div>
      <?php endwhile; ?>
      <?php $all_subs->data_seek(0); ?>
    </div>

    <!-- At-risk students -->
    <div class="card">
      <p class="card-title">
        At-Risk Students
        <?php if ($risk_result->num_rows > 0): ?>
          <span style="margin-left:auto;font-family:var(--font-mono);font-size:11px;color:var(--red);">
            <?php echo $risk_result->num_rows; ?> flagged
          </span>
        <?php endif; ?>
      </p>
      <?php if ($risk_result->num_rows === 0): ?>
        <div class="empty-state" style="padding:24px;">
          <i class="ti ti-circle-check" style="color:var(--green);font-size:28px;"></i>
          <p style="color:var(--text7);margin-top:8px;">No failing students — great job!</p>
        </div>
      <?php else: ?>
        <?php while ($r = $risk_result->fetch_assoc()):
          $initials = strtoupper(substr($r['last_name'],0,1).substr($r['first_name'],0,1));
        ?>
        <div class="risk-item">
          <div class="risk-avatar"><?php echo $initials; ?></div>
          <div>
            <div class="risk-name"><?php echo htmlspecialchars($r['last_name'].', '.$r['first_name']); ?></div>
            <div class="risk-sub">
              <?php echo htmlspecialchars($r['subject_code']); ?> — <?php echo htmlspecialchars($r['section']); ?>
            </div>
          </div>
          <div class="risk-grade"><?php echo number_format($r['letter_grade'],1); ?></div>
        </div>
        <?php endwhile; ?>
      <?php endif; ?>
    </div>

    <!-- Top & Lowest performers (each subject's own most recent activity) -->
    <div class="card">
      <p class="card-title">
        Top &amp; Lowest Performers
        <?php if (!empty($subject_perf)): ?>
          <span class="tlp-sub-count">
            <?php if ($perf_total_subjects > count($subject_perf)): ?>
              Latest <?php echo count($subject_perf); ?> of <?php echo $perf_total_subjects; ?> subjects
            <?php else: ?>
              <?php echo count($subject_perf); ?> subject<?php echo count($subject_perf)!=1?'s':''; ?>
            <?php endif; ?>
          </span>
        <?php endif; ?>
      </p>

      <?php if (empty($subject_perf)): ?>
        <div class="empty-state" style="padding:24px;">
          <i class="ti ti-pencil-off text-muted"></i>
          <p class="grey-font">No score entries yet.</p>
        </div>
      <?php else: ?>

        <?php foreach ($subject_perf as $sid => $data):
          $act  = $data['activity'];
          $pkey = 'sp' . $sid;
          $top1 = $data['top'][0]    ?? null;
          $bot1 = $data['bottom'][0] ?? null;
        ?>
        <div class="tlp-entry">
          <div class="tlp-entry-off"
              onclick="togglePerf('<?php echo $pkey; ?>')">
            <div class="per-student-performer">
              <i class="ti ti-chevron-down tlp-dd" id="perf_chev_<?php echo $pkey; ?>"></i>
              <div style="min-width:0;">
                <div class="tlp-sub-perf-title">
                  <?php echo htmlspecialchars($act['subject_code']); ?> · <?php echo htmlspecialchars($act['entry_name']); ?>
                </div>
                <div class="tlp-sec-date">
                  <?php echo htmlspecialchars($act['section']); ?> · <?php echo date('M d', strtotime($act['date_given'])); ?>
                </div>
              </div>
            </div>
            <div class="inside-chevdown3">
              <?php if ($top1):
                $p1 = $top1['total_items'] > 0 ? round($top1['score']/$top1['total_items']*100,1) : 0;
              ?>
              <span class="green-font"><i class="ti ti-arrow-up"></i> <?php echo $p1; ?>%</span>
              <?php endif; ?>
              <?php if ($bot1):
                $p2 = $bot1['total_items'] > 0 ? round($bot1['score']/$bot1['total_items']*100,1) : 0;
              ?>
              <span class="red-font"><i class="ti ti-arrow-down"></i> <?php echo $p2; ?>%</span>
              <?php endif; ?>
            </div>
          </div>

          <div id="perf_body_<?php echo $pkey; ?>" class="perf-body">
            <div class="perf-subhead green-font">
              <i class="ti ti-arrow-up"></i> Top Performers
            </div>
            <?php foreach ($data['top'] as $r):
              $pct = $r['total_items'] > 0 ? round($r['score'] / $r['total_items'] * 100, 1) : 0;
              $initials = strtoupper(substr($r['last_name'],0,1).substr($r['first_name'],0,1));
            ?>
            <div class="perf-item">
              <div class="perf-avatar">
                <?php echo $initials; ?>
              </div>
              <div>
                <div class="perf-name"><?php echo htmlspecialchars($r['last_name'].', '.$r['first_name']); ?></div>
                <div class="perf-sub"><?php echo (int)$r['score'].'/'.(int)$r['total_items']; ?></div>
              </div>
              <div class="perf-score text-green"><?php echo $pct; ?>%</div>
            </div>
            <?php endforeach; ?>

            <div class="perf-subhead">
              <i class="ti ti-arrow-down"></i> Lowest Performers
            </div>
            <?php if (empty($data['bottom'])): ?>
              <p class="empty-state2">Not enough separate scores yet to list lowest performers.</p>
            <?php else: ?>
              <?php foreach ($data['bottom'] as $r):
                $pct = $r['total_items'] > 0 ? round($r['score'] / $r['total_items'] * 100, 1) : 0;
                $initials = strtoupper(substr($r['last_name'],0,1).substr($r['first_name'],0,1));
              ?>
              <div class="perf-item perf-item-lowest">
                <div class="perf-avatar perf-avatar-lowest">
                  <?php echo $initials; ?>
                </div>
                <div>
                  <div class="perf-name"><?php echo htmlspecialchars($r['last_name'].', '.$r['first_name']); ?></div>
                  <div class="perf-sub"><?php echo (int)$r['score'].'/'.(int)$r['total_items']; ?></div>
                </div>
                <div class="perf-score text-red"><?php echo $pct; ?>%</div>
              </div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>

      <?php endif; ?>
    </div>

    <!-- Recent score entries -->
    <div class="card">
      <p class="card-title">
        Recent Entries
      </p>
      <?php if ($recent->num_rows === 0): ?>
        <div class="empty-state" style="padding:24px;">
          <i class="ti ti-pencil-off text-muted"></i>
          <p class="grey-font">No score entries yet.</p>
        </div>
      <?php else: ?>
        <?php while ($r = $recent->fetch_assoc()):
          $cc = $comp_colors[$r['component']] ?? ['color'=>'#7aa3ff','icon'=>'ti-pencil'];
          $pct = $r['total_items'] > 0 ? round($r['score']/$r['total_items']*100,1) : 0;
        ?>
        <div class="recent-item">
          <div class="recent-icon" style="background:<?php echo $cc['color']; ?>18;color:<?php echo $cc['color']; ?>;">
            <i class="ti <?php echo $cc['icon']; ?>"></i>
          </div>
          <div class="recent-main">
            <div class="recent-title">
              <?php echo htmlspecialchars($r['entry_name']); ?>
              <span>
                &nbsp; · &nbsp;&nbsp;<?php echo htmlspecialchars($r['subject_code']); ?>
              </span>
            </div>
            <div class="recent-sub">
              <?php echo htmlspecialchars($r['last_name'].', '.$r['first_name']); ?>
              &nbsp; ·<?php echo date('M d', strtotime($r['date_given'])); ?>
            </div>
          </div>
          <div class="recent-score">
            <?php echo $r['score'].'/'.$r['total_items']; ?>
            <span style="color:<?php echo $pct>=75?'var(--green)':'var(--red)'; ?>;">
              (<?php echo $pct; ?>%)
            </span>
          </div>
        </div>
        <?php endwhile; ?>
      <?php endif; ?>
    </div>

  </div>
  <?php endif; ?>

</div>

<script>
function toggleDD(){
  document.getElementById('ddMenu').classList.toggle('open');
  document.getElementById('ddBtn').classList.toggle('open');
}
document.addEventListener('click',e=>{
  const dd=document.querySelector('.nav-dropdown');
  if(dd&&!dd.contains(e.target)){
    document.getElementById('ddMenu')?.classList.remove('open');
    document.getElementById('ddBtn')?.classList.remove('open');
  }
});

// ── Top/Lowest performers per-subject accordion ──────
function togglePerf(key) {
  const body = document.getElementById('perf_body_' + key);
  const chev = document.getElementById('perf_chev_' + key);
  if (!body) return;
  const isOpen = body.style.display !== 'none';
  body.style.display = isOpen ? 'none' : 'block';
  if (chev) chev.style.transform = isOpen ? '' : 'rotate(180deg)';
}

</script>

</main>
</div>
<script src="/classroomv2/assets/ui.js" defer></script>
<script src="/classroomv2/assets/pwa.js" defer></script>
</body>
</html>
<!--PHPEOF
echo "done"-->