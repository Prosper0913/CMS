-- Adds 'Excused' to attendance.status (keeps every existing value, null-ability and default).
-- Run ONCE as root BEFORE deploying the new PHP. Safe to run again.
SET @type := (SELECT COLUMN_TYPE FROM information_schema.COLUMNS
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'attendance' AND COLUMN_NAME = 'status');
SET @null := (SELECT IF(IS_NULLABLE = 'NO', ' NOT NULL', ' NULL') FROM information_schema.COLUMNS
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'attendance' AND COLUMN_NAME = 'status');
SET @def  := (SELECT IF(COLUMN_DEFAULT IS NULL, '', CONCAT(' DEFAULT ''', COLUMN_DEFAULT, ''''))
              FROM information_schema.COLUMNS
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'attendance' AND COLUMN_NAME = 'status');
SET @sql := IF(@type LIKE 'enum(%' AND @type NOT LIKE '%Excused%',
  CONCAT('ALTER TABLE attendance MODIFY status ',
         REPLACE(@type, '''Absent''', '''Absent'',''Excused'''), @null, @def),
  'SELECT ''attendance.status already accepts Excused (or is not an enum) - nothing to do''');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SELECT COLUMN_TYPE AS attendance_status_type FROM information_schema.COLUMNS
 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'attendance' AND COLUMN_NAME = 'status';
