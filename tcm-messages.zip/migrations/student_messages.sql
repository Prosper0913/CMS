-- Direct messages from a teacher to one student (one-way, max 500 words enforced in PHP).
-- Safe to run more than once.
CREATE TABLE IF NOT EXISTS student_messages (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  subject_id  INT NOT NULL,
  teacher_id  INT NOT NULL,
  student_id  VARCHAR(50) NOT NULL,
  body        TEXT NOT NULL,
  word_count  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  read_at     DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (id),
  KEY idx_msg_student (student_id, created_at),
  KEY idx_msg_subject (subject_id, teacher_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
