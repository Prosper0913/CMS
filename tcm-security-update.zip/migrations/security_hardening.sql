-- ============================================================
--  migrations/security_hardening.sql
--  Run ONCE on the live database BEFORE deploying the new PHP files
--  (login.php reads users.must_change_password).
--  Safe to run again: every step checks first.
--
--  mysql -u root -p YOUR_DB_NAME < migrations/security_hardening.sql
-- ============================================================

-- 1) users.must_change_password  (1 = must set own password + Gmail at next sign-in)
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'must_change_password');
SET @sql := IF(@c = 0,
  'ALTER TABLE users ADD COLUMN must_change_password TINYINT(1) NOT NULL DEFAULT 0',
  'SELECT ''must_change_password already exists''');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 2) users.email_verified_at
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'email_verified_at');
SET @sql := IF(@c = 0,
  'ALTER TABLE users ADD COLUMN email_verified_at DATETIME NULL DEFAULT NULL',
  'SELECT ''email_verified_at already exists''');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 3) otp_codes.purpose must accept 'first_login' and 'contact_update'
--    (if it was created as an ENUM of just 'password_reset', make it a VARCHAR)
SET @t := (SELECT DATA_TYPE FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'otp_codes' AND COLUMN_NAME = 'purpose');
SET @sql := IF(@t = 'enum',
  'ALTER TABLE otp_codes MODIFY purpose VARCHAR(40) NOT NULL',
  'SELECT ''otp_codes.purpose is not an enum - nothing to do''');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 4) speeds up the failed-login counts used by login throttling
SET @c := (SELECT COUNT(*) FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'audit_log' AND INDEX_NAME = 'idx_login_throttle');
SET @sql := IF(@c = 0,
  'ALTER TABLE audit_log ADD INDEX idx_login_throttle (event_type, outcome, created_at)',
  'SELECT ''idx_login_throttle already exists''');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ------------------------------------------------------------
-- OPTIONAL — force EXISTING accounts through the first-login setup too.
-- By default existing users are NOT forced (new accounts and admin
-- resets are). Uncomment what you want:
--
-- UPDATE users SET must_change_password = 1 WHERE role = 'student';
-- UPDATE users SET must_change_password = 1 WHERE role = 'teacher';
-- ------------------------------------------------------------
